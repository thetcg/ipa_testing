import React, { useState, useEffect, useMemo, useRef } from 'react';
import { createRoot } from 'react-dom/client';

// --- TYPES & CONSTANTS ---
type Category = 'PHOTO' | 'DOCUMENT' | 'WEB_ADDRESS' | 'PASSWORD' | 'TEXT';

interface StoredItem {
  id: string;
  title: string;
  category: Category;
  createdAt: string;
  // Content can vary based on category
  content?: string; // For text, URL, username
  password?: string; // For passwords
  fileName?: string; // For files
  fileData?: string; // Base64 data for files
  website?: string; // For password category
}

const CATEGORIES: Category[] = ['PHOTO', 'DOCUMENT', 'WEB_ADDRESS', 'PASSWORD', 'TEXT'];

const APP_PASSWORD_KEY = 'TCG_DOCUMENT_LOCK_PASSWORD';
const APP_DATA_KEY = 'TCG_DOCUMENT_LOCK_DATA';
const PRESET_RESET_PASSWORD = '0009679';

// --- HELPER FUNCTIONS ---
const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

const Icon = ({ category }: { category: Category }) => {
  const SvgIcon = {
    PHOTO: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>
    ),
    DOCUMENT: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
    ),
    WEB_ADDRESS: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" /></svg>
    ),
    PASSWORD: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z" /></svg>
    ),
    TEXT: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25H12" /></svg>
    ),
  };
  return SvgIcon[category] || null;
};

// --- COMPONENTS ---

const AuthComponent = ({ onLogin }: { onLogin: () => void }) => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isSetupMode, setIsSetupMode] = useState(false);
  const [isResetMode, setIsResetMode] = useState(false);
  const [resetCode, setResetCode] = useState('');

  useEffect(() => {
    const storedPassword = localStorage.getItem(APP_PASSWORD_KEY);
    if (!storedPassword) {
      setIsSetupMode(true);
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const storedPassword = localStorage.getItem(APP_PASSWORD_KEY);
    if (password === storedPassword) {
      onLogin();
    } else {
      setError('Incorrect password.');
    }
  };

  const handleSetup = (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 4) {
      setError('Password must be at least 4 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    // In a real app, hash the password before storing
    localStorage.setItem(APP_PASSWORD_KEY, password);
    onLogin();
  };
  
  const handleReset = (e: React.FormEvent) => {
    e.preventDefault();
    if (resetCode === PRESET_RESET_PASSWORD) {
        setError('');
        setResetCode('');
        setIsResetMode(false);
        setIsSetupMode(true);
        setPassword('');
        setConfirmPassword('');
    } else {
        setError('Incorrect reset code.');
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <h1>🔐 TCG Document Lock</h1>

        {isResetMode ? (
            <>
                <p>Enter the preset code to reset your password.</p>
                <form onSubmit={handleReset}>
                    <div className="input-group">
                        <label htmlFor="reset-code">Reset Code</label>
                        <input
                            type="password"
                            id="reset-code"
                            value={resetCode}
                            onChange={(e) => setResetCode(e.target.value)}
                            required
                        />
                    </div>
                    {error && <p className="error-message">{error}</p>}
                    <button type="submit" className="btn">Reset Password</button>
                    <button 
                        type="button" 
                        className="btn btn-secondary" 
                        style={{marginTop: '10px'}} 
                        onClick={() => { setIsResetMode(false); setError(''); }}>
                        Cancel
                    </button>
                </form>
            </>
        ) : (
            <>
                <p>{isSetupMode ? 'Create a master password to secure your vault.' : 'Enter your master password to unlock.'}</p>
                <form onSubmit={isSetupMode ? handleSetup : handleLogin}>
                  <div className="input-group">
                    <label htmlFor="password">Master Password</label>
                    <input
                      type="password"
                      id="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                  {isSetupMode && (
                    <div className="input-group">
                      <label htmlFor="confirm-password">Confirm Password</label>
                      <input
                        type="password"
                        id="confirm-password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                      />
                    </div>
                  )}
                  {error && <p className="error-message">{error}</p>}
                  <button type="submit" className="btn">
                    {isSetupMode ? 'Create Vault' : 'Unlock'}
                  </button>
                </form>
                {!isSetupMode && (
                    <button type="button" className="forgot-password-btn" onClick={() => { setIsResetMode(true); setError(''); }}>
                        Forgot Password?
                    </button>
                )}
            </>
        )}
      </div>
    </div>
  );
};

const AddItemModal = ({ onClose, onSave }: { onClose: () => void, onSave: (item: Omit<StoredItem, 'id' | 'createdAt'>) => void }) => {
    const [title, setTitle] = useState('');
    const [category, setCategory] = useState<Category>('TEXT');
    const [content, setContent] = useState('');
    const [password, setPassword] = useState('');
    const [website, setWebsite] = useState('');
    const [file, setFile] = useState<File | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        let newItem: Omit<StoredItem, 'id' | 'createdAt'> = { title, category };

        if (category === 'PHOTO' || category === 'DOCUMENT') {
            if (file) {
                newItem.fileName = file.name;
                newItem.fileData = await fileToBase64(file);
            }
        } else if (category === 'TEXT') {
            newItem.content = content;
        } else if (category === 'WEB_ADDRESS') {
            newItem.content = content; // URL stored in content
        } else if (category === 'PASSWORD') {
            newItem.content = content; // Username stored in content
            newItem.password = password;
            newItem.website = website;
        }
        onSave(newItem);
    };

    const renderCategoryFields = () => {
        switch (category) {
            case 'TEXT':
                return (
                    <div className="input-group">
                        <label htmlFor="content">Content</label>
                        <textarea id="content" value={content} onChange={e => setContent(e.target.value)} required />
                    </div>
                );
            case 'WEB_ADDRESS':
                return (
                    <div className="input-group">
                        <label htmlFor="url">Website URL</label>
                        <input type="url" id="url" value={content} onChange={e => setContent(e.target.value)} required />
                    </div>
                );
            case 'PASSWORD':
                return (
                    <>
                        <div className="input-group">
                            <label htmlFor="website">Website (optional)</label>
                            <input type="text" id="website" value={website} onChange={e => setWebsite(e.target.value)} />
                        </div>
                        <div className="input-group">
                            <label htmlFor="username">Username/Email</label>
                            <input type="text" id="username" value={content} onChange={e => setContent(e.target.value)} required />
                        </div>
                        <div className="input-group">
                            <label htmlFor="password-field">Password</label>
                            <input type="password" id="password-field" value={password} onChange={e => setPassword(e.target.value)} required />
                        </div>
                    </>
                );
            case 'PHOTO':
            case 'DOCUMENT':
                return (
                    <div className="input-group">
                        <label htmlFor="file">File</label>
                        <input type="file" id="file" onChange={e => setFile(e.target.files ? e.target.files[0] : null)} required 
                          accept={category === 'PHOTO' ? 'image/*' : '.pdf,.doc,.docx,.txt,.xls,.xlsx'}/>
                    </div>
                );
            default: return null;
        }
    }

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <h2>Add New Item</h2>
                <form onSubmit={handleSubmit}>
                    <div className="input-group">
                        <label htmlFor="title">Title</label>
                        <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} required />
                    </div>
                    <div className="input-group">
                        <label htmlFor="category">Category</label>
                        <select id="category" value={category} onChange={e => setCategory(e.target.value as Category)}>
                            {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat.replace('_', ' ')}</option>)}
                        </select>
                    </div>
                    {renderCategoryFields()}
                    <div className="modal-actions">
                        <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
                        <button type="submit" className="btn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const ItemDetailModal = ({ item, onClose, onDelete }: { item: StoredItem, onClose: () => void, onDelete: (id: string) => void }) => {
    
    const [showPassword, setShowPassword] = useState(false);
    const [copyDetailsButtonText, setCopyDetailsButtonText] = useState('Copy Details');


    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
        // Add user feedback here e.g. toast notification
    }

    const handleCopyAllDetails = () => {
        let details = `Title: ${item.title}\nCategory: ${item.category.replace('_', ' ')}\nDate Added: ${new Date(item.createdAt).toLocaleDateString()}`;
        
        switch(item.category) {
            case 'TEXT':
                details += `\nContent: ${item.content}`;
                break;
            case 'WEB_ADDRESS':
                details += `\nURL: ${item.content}`;
                break;
            case 'PASSWORD':
                if (item.website) details += `\nWebsite: ${item.website}`;
                details += `\nUsername: ${item.content}`;
                details += `\nPassword: ${item.password}`;
                break;
            case 'PHOTO':
            case 'DOCUMENT':
                if (item.fileName) details += `\nFilename: ${item.fileName}`;
                break;
        }

        navigator.clipboard.writeText(details);
        setCopyDetailsButtonText('Copied!');
        setTimeout(() => {
            setCopyDetailsButtonText('Copy Details');
        }, 2000);
    };
    
    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content detail-view" onClick={e => e.stopPropagation()}>
                <div className="detail-view-header">
                    <Icon category={item.category} />
                    <h2>{item.title}</h2>
                </div>
                
                <p><strong>Category:</strong> {item.category.replace('_', ' ')}</p>
                <p><strong>Date Added:</strong> {new Date(item.createdAt).toLocaleDateString()}</p>
                
                {item.category === 'TEXT' && <div className="detail-content">{item.content}</div>}
                
                {item.category === 'WEB_ADDRESS' && (
                  <div className="detail-content">
                    <a href={item.content} target="_blank" rel="noopener noreferrer">{item.content}</a>
                    <button className="copy-btn" onClick={() => copyToClipboard(item.content!)}>Copy</button>
                  </div>
                )}

                {item.category === 'PASSWORD' && (
                    <>
                        {item.website && <p><strong>Website:</strong> <a href={item.website} target="_blank" rel="noopener noreferrer">{item.website}</a></p>}
                        <p><strong>Username:</strong></p>
                        <div className="detail-content">
                           {item.content}
                           <button className="copy-btn" onClick={() => copyToClipboard(item.content!)}>Copy</button>
                        </div>
                        <p style={{marginTop: '1rem'}}><strong>Password:</strong></p>
                        <div className="detail-content password-input-wrapper">
                            <input type={showPassword ? 'text' : 'password'} value={item.password} readOnly style={{border: 'none', background: 'transparent', width: '100%', padding: 0}}/>
                            <button className="toggle-password" onClick={() => setShowPassword(!showPassword)}>{showPassword ? 'Hide' : 'Show'}</button>
                            <button className="copy-btn" style={{right: '50px'}} onClick={() => copyToClipboard(item.password!)}>Copy</button>
                        </div>
                    </>
                )}

                {(item.category === 'PHOTO' || item.category === 'DOCUMENT') && (
                    <div className="file-preview">
                        {item.category === 'PHOTO' && item.fileData && <img src={item.fileData} alt={item.fileName} />}
                        <p>{item.fileName}</p>
                        <a href={item.fileData} download={item.fileName} className="btn">Download</a>
                    </div>
                )}
                
                <div className="modal-actions">
                    <button className="btn btn-danger" onClick={() => onDelete(item.id)}>Delete</button>
                    <button className="btn btn-secondary" onClick={handleCopyAllDetails}>{copyDetailsButtonText}</button>
                    <button className="btn btn-secondary" onClick={onClose}>Return to Main Page</button>
                </div>
            </div>
        </div>
    );
};

const MainApp = ({ onLogout }: { onLogout: () => void }) => {
  const [items, setItems] = useState<StoredItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<Category | 'ALL'>('ALL');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<StoredItem | null>(null);
  const [isActionsMenuOpen, setIsActionsMenuOpen] = useState(false);
  const actionsMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const storedData = localStorage.getItem(APP_DATA_KEY);
    if (storedData) {
      setItems(JSON.parse(storedData));
    }
  }, []);
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (actionsMenuRef.current && !actionsMenuRef.current.contains(event.target as Node)) {
            setIsActionsMenuOpen(false);
        }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
        document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const saveItems = (updatedItems: StoredItem[]) => {
      setItems(updatedItems);
      localStorage.setItem(APP_DATA_KEY, JSON.stringify(updatedItems));
  }

  const handleAddItem = (newItemData: Omit<StoredItem, 'id' | 'createdAt'>) => {
    const newItem: StoredItem = {
      ...newItemData,
      id: new Date().toISOString() + Math.random(), // Add random number to ensure unique ID
      createdAt: new Date().toISOString(),
    };
    const updatedItems = [...items, newItem].sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    saveItems(updatedItems);
    setIsAddModalOpen(false);
  };

  const handleDeleteItem = (id: string) => {
    if(window.confirm('Are you sure you want to delete this item?')) {
        const updatedItems = items.filter(item => item.id !== id);
        saveItems(updatedItems);
        setSelectedItem(null);
    }
  };

  const filteredItems = useMemo(() => {
    return items.filter(item => {
      const matchesCategory = filterCategory === 'ALL' || item.category === filterCategory;
      const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [items, searchTerm, filterCategory]);

  const handleExport = () => {
    if (filteredItems.length === 0) {
        alert("No items to export.");
        return;
    }
    const headers = ['Title', 'Category', 'Date Added', 'Website', 'Filename'];
    const rows = filteredItems.map(item => [
        `"${item.title.replace(/"/g, '""')}"`,
        item.category.replace('_', ' '),
        new Date(item.createdAt).toLocaleDateString(),
        item.website || '',
        item.fileName || ''
    ].join(','));
    
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `tcg_lock_export_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setIsActionsMenuOpen(false);
  };

  const handleShareByEmail = () => {
    if (filteredItems.length === 0) {
        alert("No items to share.");
        return;
    }
    const subject = "TCG Document Lock - Item Summary";
    const body = filteredItems.map(item => {
        let details = `Title: ${item.title}\nCategory: ${item.category.replace('_', ' ')}\nDate Added: ${new Date(item.createdAt).toLocaleDateString()}`;
        if (item.website) details += `\nWebsite: ${item.website}`;
        if (item.fileName) details += `\nFilename: ${item.fileName}`;
        return details;
    }).join('\n\n---\n\n');
    
    const mailtoLink = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent("Here is a summary of my stored items:\n\n" + body)}`;
    window.location.href = mailtoLink;
    setIsActionsMenuOpen(false);
  };

  return (
    <div className="app-container">
      <header>
          <div className="header-content">
            <h1>TCG Document Lock</h1>
             <div className="header-actions" ref={actionsMenuRef}>
                <button onClick={() => setIsActionsMenuOpen(prev => !prev)} className="actions-btn" aria-haspopup="true" aria-expanded={isActionsMenuOpen}>
                    Actions ▾
                </button>
                {isActionsMenuOpen && (
                    <div className="actions-dropdown">
                        <button onClick={handleExport}>Export Summary (CSV)</button>
                        <button onClick={handleShareByEmail}>Share via Email</button>
                    </div>
                )}
                <button onClick={onLogout} className="logout-btn">Logout</button>
            </div>
          </div>
      </header>
      <main>
        <div className="controls">
            <input 
                type="search"
                placeholder="Search by title..."
                className="search-bar"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
            />
            <div className="category-filters">
                <button className={`filter-btn ${filterCategory === 'ALL' ? 'active': ''}`} onClick={() => setFilterCategory('ALL')}>All</button>
                {CATEGORIES.map(cat => (
                    <button key={cat} className={`filter-btn ${filterCategory === cat ? 'active': ''}`} onClick={() => setFilterCategory(cat)}>{cat.replace('_', ' ')}</button>
                ))}
            </div>
        </div>

        {filteredItems.length > 0 ? (
            <div className="item-list">
                {filteredItems.map(item => (
                    <div className="item-card" key={item.id} onClick={() => setSelectedItem(item)}>
                        <button
                            className="delete-item-btn"
                            onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteItem(item.id);
                            }}
                            aria-label={`Delete ${item.title}`}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.134-2.033-2.134H8.716c-1.123 0-2.033.954-2.033 2.134v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                            </svg>
                        </button>
                        <div className="item-card-header">
                            <Icon category={item.category} />
                            <h3>{item.title}</h3>
                        </div>
                        <p>Category: {item.category.replace('_', ' ')}</p>
                        <p>Added: {new Date(item.createdAt).toLocaleDateString()}</p>
                    </div>
                ))}
            </div>
        ) : (
            <div className="no-items">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" /></svg>
                <h2>No items found.</h2>
                <p>Try adjusting your search or filters, or add a new item.</p>
            </div>
        )}
      </main>
      <button className="add-btn" onClick={() => setIsAddModalOpen(true)}>+</button>
      {isAddModalOpen && <AddItemModal onClose={() => setIsAddModalOpen(false)} onSave={handleAddItem} />}
      {selectedItem && <ItemDetailModal item={selectedItem} onClose={() => setSelectedItem(null)} onDelete={handleDeleteItem} />}
    </div>
  );
};

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };
  
  const handleLogout = () => {
    setIsAuthenticated(false);
  }

  if (!isAuthenticated) {
    return <AuthComponent onLogin={handleLogin} />;
  }

  return <MainApp onLogout={handleLogout} />;
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);